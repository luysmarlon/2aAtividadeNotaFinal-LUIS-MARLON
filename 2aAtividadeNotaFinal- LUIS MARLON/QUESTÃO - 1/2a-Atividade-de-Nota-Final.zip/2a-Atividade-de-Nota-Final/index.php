<?php
$caminhoBanco = __DIR__ . '/meu_banco.db';
$conexao = new PDO("sqlite:$caminhoBanco");
$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Criação da tabela se ainda não existir
$conexao->exec("CREATE TABLE IF NOT EXISTS biblioteca (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    autor TEXT NOT NULL,
    ano_publicacao INTEGER NOT NULL
)");

// Exclusão de registro se necessario a se solicitado
if (!empty($_GET['remover'])) {
    $codigo = (int) $_GET['remover'];
    $comando = $conexao->prepare("DELETE FROM acervo WHERE id = ?");
    $comando->execute([$codigo]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Inserir livros
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nomeLivro = $_POST['titulo'] ?? '';
    $nomeAutor = $_POST['autor'] ?? '';
    $anoLivro = $_POST['ano'] ?? '';

    if (trim($nomeLivro) && trim($nomeAutor) && trim($anoLivro)) {
        $cmd = $conexao->prepare("INSERT INTO acervo (titulo, autor, ano_publicacao) VALUES (?, ?, ?)");
        $cmd->execute([$nomeLivro, $nomeAutor, $anoLivro]);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$listaLivros = $conexao->query("SELECT * FROM acervo ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Amazenamento de Livros</title>
    <style>
        blackground-color: #black;
        body { font-family: Verdana, sans-serif; margin: 25px; }
        h1, h2 { color: #2c2c2c; font-size: 35px;}
        form input, form button {margin: 6px 0; padding: 7px; width: 100%; max-width: 300px;}
        table {width: 100%; border-collapse: collapse; margin-top: 25px; }
        th, td { border: 1px solid #bbb; padding: 10px; }
        th {background-color: #e9e9e9; }
        a.botao-excluir { color: #c00; text-decoration: none; font-weight: bold;}
    </style>
</head>
<body>
    <h1> Adicionar livro na biblioteca</h1>
     <form method="post">
        <label>Título do Livro:</label><br>
        <input type="text" name="titulo" required><br>

        <label>Autor:</label><br>
        <input type="text" name="autor" required><br>

        <label>Publicação:</label><br>
        <input type="number" name="ano" required><br>

        <button type="submit">Registrar Livro</button>
    </form>
 <h2>Lista de Livros:</h2>
    
    <!--Banco de dados-->
    <?php if (count($listaLivros) > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Autor</th>
                <th>Ano</th>
                <th>Função</th>
            </tr>
            <?php foreach ($listaLivros as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['id']) ?></td>
                    <td><?= htmlspecialchars($item['titulo']) ?></td>
                    <td><?= htmlspecialchars($item['autor']) ?></td>
                    <td><?= htmlspecialchars($item['ano_publicacao']) ?></td>
                    <td>
                        <a class="botao-excluir" href="?remover=<?= $item['id'] ?>" onclick="return confirm('Tem certeza que deseja apagar este livro?')">Remover</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Não há livros registrados ainda</p>
    <?php endif; ?>
</body>
</html>
